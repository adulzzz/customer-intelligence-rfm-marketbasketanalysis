# ============================================================
# FASE 5: DASHBOARD INTERAKTIF (Streamlit)
# Project: Customer Intelligence - Online Retail II
# Jalankan: streamlit run fase5_dashboard.py
# ============================================================

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import ast
import warnings
warnings.filterwarnings('ignore')

# ============================================================
# KONFIGURASI HALAMAN
# ============================================================
st.set_page_config(
    page_title="Customer Intelligence Dashboard",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.markdown("""
<style>
    .metric-container { background: #f8f9fa; border-radius: 10px; padding: 1rem; }
    .stMetric { background: #f8f9fa; border-radius: 8px; padding: 0.5rem; }
</style>
""", unsafe_allow_html=True)


# ============================================================
# LOAD DATA
# ============================================================
@st.cache_data
def load_data():
    rfm = pd.read_csv('rfm_clustered.csv')
    rules = pd.read_csv('association_rules.csv')

    def safe_parse(x):
        try:
            return list(ast.literal_eval(x))
        except:
            return [str(x)]

    rules['antecedents'] = rules['antecedents'].apply(safe_parse)
    rules['consequents'] = rules['consequents'].apply(safe_parse)
    rules['ant_str'] = rules['antecedents'].apply(lambda x: ', '.join(x))
    rules['con_str'] = rules['consequents'].apply(lambda x: ', '.join(x))
    return rfm, rules

rfm, rules = load_data()


# ============================================================
# SIDEBAR — FILTER
# ============================================================
st.sidebar.image("https://via.placeholder.com/200x60?text=Online+Retail+II", width=200)
st.sidebar.title("Filter Dashboard")

selected_segs = st.sidebar.multiselect(
    "Pilih Segmen",
    options=rfm['Segment'].unique().tolist(),
    default=rfm['Segment'].unique().tolist()
)

min_lift = st.sidebar.slider("Minimum Lift (MBA)", 1.0, 10.0, 1.5, 0.1)
top_n_rules = st.sidebar.slider("Tampilkan Top N Rules", 5, 30, 10)

rfm_filtered = rfm[rfm['Segment'].isin(selected_segs)]
rules_filtered = rules[rules['lift'] >= min_lift].nlargest(top_n_rules, 'lift')


# ============================================================
# HEADER
# ============================================================
st.title("📊 Customer Intelligence Dashboard")
st.markdown("**Online Retail II** · Segmentasi RFM (K-Means) + Market Basket Analysis (FP-Growth)")
st.divider()


# ============================================================
# ROW 1: KPI METRICS
# ============================================================
col1, col2, col3, col4, col5 = st.columns(5)

with col1:
    st.metric("Total Pelanggan", f"{len(rfm_filtered):,}",
              delta=f"{len(rfm_filtered)/len(rfm)*100:.0f}% dari total")
with col2:
    st.metric("Total Revenue", f"£{rfm_filtered['Monetary'].sum():,.0f}")
with col3:
    st.metric("Avg Recency", f"{rfm_filtered['Recency'].mean():.0f} hari")
with col4:
    st.metric("Avg Frequency", f"{rfm_filtered['Frequency'].mean():.1f}x")
with col5:
    st.metric("Association Rules", f"{len(rules_filtered):,}",
              delta=f"lift ≥ {min_lift}")

st.divider()


# ============================================================
# ROW 2: SEGMENTASI
# ============================================================
st.subheader("🎯 Segmentasi Pelanggan")

col_left, col_right = st.columns([1, 1])

SEG_COLORS = {
    'Champions'         : '#E24B4A',
    'Loyal Customers'   : '#378ADD',
    'Potential Loyalist': '#639922',
    'At-Risk / Lost'    : '#888780'
}

with col_left:
    seg_count = rfm_filtered['Segment'].value_counts().reset_index()
    seg_count.columns = ['Segment', 'Count']
    seg_count['Color'] = seg_count['Segment'].map(SEG_COLORS)

    fig_pie = px.pie(
        seg_count, values='Count', names='Segment',
        color='Segment', color_discrete_map=SEG_COLORS,
        title='Proporsi Jumlah Pelanggan'
    )
    fig_pie.update_traces(textposition='inside', textinfo='percent+label')
    fig_pie.update_layout(showlegend=False, height=320, margin=dict(t=50,b=10))
    st.plotly_chart(fig_pie, use_container_width=True)

with col_right:
    seg_rev = rfm_filtered.groupby('Segment')['Monetary'].sum().reset_index()
    seg_rev.columns = ['Segment', 'Revenue']
    seg_rev = seg_rev.sort_values('Revenue', ascending=True)
    seg_rev['Color'] = seg_rev['Segment'].map(SEG_COLORS)

    fig_rev = px.bar(
        seg_rev, x='Revenue', y='Segment', orientation='h',
        color='Segment', color_discrete_map=SEG_COLORS,
        title='Kontribusi Revenue per Segmen (£)',
        text=seg_rev['Revenue'].apply(lambda x: f'£{x:,.0f}')
    )
    fig_rev.update_layout(showlegend=False, height=320, margin=dict(t=50,b=10))
    fig_rev.update_traces(textposition='outside')
    st.plotly_chart(fig_rev, use_container_width=True)


# ============================================================
# ROW 3: PROFIL RFM DETAIL
# ============================================================
st.subheader("📋 Profil RFM per Segmen")

profile = rfm_filtered.groupby('Segment').agg(
    Pelanggan  = ('Customer ID', 'count'),
    Avg_R      = ('Recency', 'mean'),
    Avg_F      = ('Frequency', 'mean'),
    Avg_M      = ('Monetary', 'mean'),
    Total_Rev  = ('Monetary', 'sum')
).round(2).reset_index()
profile['Rev_Share'] = (profile['Total_Rev'] / rfm['Monetary'].sum() * 100).round(1)

st.dataframe(
    profile.rename(columns={
        'Segment': 'Segmen', 'Pelanggan': 'Jml Pelanggan',
        'Avg_R': 'Avg Recency (hari)', 'Avg_F': 'Avg Frequency',
        'Avg_M': 'Avg Monetary (£)', 'Total_Rev': 'Total Revenue (£)',
        'Rev_Share': 'Revenue Share (%)'
    }).style.background_gradient(subset=['Avg Monetary (£)', 'Revenue Share (%)'],
                                  cmap='RdYlGn'),
    use_container_width=True
)


# ============================================================
# ROW 4: SCATTER RFM
# ============================================================
st.subheader("🔵 Scatter Plot Segmen (Recency vs Monetary)")

fig_scatter = px.scatter(
    rfm_filtered,
    x='Recency', y='Monetary',
    color='Segment', color_discrete_map=SEG_COLORS,
    size='Frequency', size_max=20,
    opacity=0.6,
    hover_data=['Customer ID', 'Recency', 'Frequency', 'Monetary'],
    labels={'Recency': 'Recency (hari)', 'Monetary': 'Monetary (£)'},
    title='Segmentasi Pelanggan: Recency vs Monetary (ukuran = Frequency)'
)
fig_scatter.update_layout(height=400)
st.plotly_chart(fig_scatter, use_container_width=True)


# ============================================================
# ROW 5: MARKET BASKET ANALYSIS
# ============================================================
st.divider()
st.subheader("🛍️ Market Basket Analysis — Rekomendasi Bundling")

col_mba1, col_mba2 = st.columns([1.2, 0.8])

with col_mba1:
    fig_mba = px.scatter(
        rules_filtered,
        x='support', y='confidence',
        size='lift', color='lift',
        color_continuous_scale='YlOrRd',
        hover_data=['ant_str', 'con_str', 'lift', 'confidence', 'support'],
        labels={'ant_str': 'Antecedent', 'con_str': 'Consequent'},
        title=f'Support vs Confidence (lift ≥ {min_lift}, ukuran = lift)'
    )
    fig_mba.update_layout(height=360)
    st.plotly_chart(fig_mba, use_container_width=True)

with col_mba2:
    st.markdown("**Top Association Rules**")
    display_rules = rules_filtered[['ant_str', 'con_str', 'support', 'confidence', 'lift']].copy()
    display_rules.columns = ['Jika Beli', 'Rekomendasikan', 'Support', 'Confidence', 'Lift']
    display_rules = display_rules.round(3)
    st.dataframe(display_rules, use_container_width=True, height=340)


# ============================================================
# ROW 6: REKOMENDASI BISNIS
# ============================================================
st.divider()
st.subheader("💡 Rekomendasi Bisnis per Segmen")

rekom = {
    'Champions': {
        'icon': '👑', 'color': '#FCEBEB',
        'strategi': ['VIP membership & early access produk', 'Cashback & reward program',
                     'Brand ambassador & referral', 'Bundling produk premium eksklusif']
    },
    'Loyal Customers': {
        'icon': '⭐', 'color': '#EBF3FC',
        'strategi': ['Upselling produk margin tinggi', 'Cross-sell berbasis MBA rules',
                     'Milestone reward per X transaksi', 'Subscribe & save produk rutin']
    },
    'Potential Loyalist': {
        'icon': '🌱', 'color': '#EAF3DE',
        'strategi': ['Welcome offer diskon pembelian ke-2', 'Email onboarding 5 tahap (30 hari)',
                     'Rekomendasi produk populer dari MBA', 'Free shipping threshold']
    },
    'At-Risk / Lost': {
        'icon': '⚠️', 'color': '#F5F5F4',
        'strategi': ['Win-back campaign + voucher 20%', 'Survey alasan tidak aktif',
                     'Retargeting ads sosial media', 'Last chance offer (waktu terbatas)']
    }
}

cols = st.columns(len(selected_segs))
for i, seg in enumerate(selected_segs):
    if seg in rekom:
        info = rekom[seg]
        with cols[i]:
            st.markdown(f"""
            <div style="background:{info['color']};border-radius:10px;padding:1rem;height:200px;">
              <div style="font-size:20px;margin-bottom:6px;">{info['icon']}</div>
              <div style="font-size:13px;font-weight:600;margin-bottom:8px;">{seg}</div>
              {"".join(f'<div style="font-size:11px;margin-bottom:4px;color:#444;">• {s}</div>' for s in info['strategi'])}
            </div>
            """, unsafe_allow_html=True)


# ============================================================
# FOOTER
# ============================================================
st.divider()
st.caption("Dashboard Fase 5 · Final Project Data Mining · Online Retail II · "
           "Teknik: RFM K-Means + FP-Growth MBA")